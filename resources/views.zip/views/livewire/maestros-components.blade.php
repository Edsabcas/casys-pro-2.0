<div class="container">
    @include('maestros.formulario')
   
    <br>

    <div>
        @include('maestros.listar')
    </div>
</div>
