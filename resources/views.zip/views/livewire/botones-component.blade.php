<div class='container'>
    <div>
    @include('Temas.Pre_kinder')
    </div>
</div>
