<div class="contenido">
    @include('auth.rolesdeusuario')   
</div>