<div class="container">
    @include('Grados.nivelacademico')
 
    <div>
        @include('grados.listarnivel')
     </div>
 </div>