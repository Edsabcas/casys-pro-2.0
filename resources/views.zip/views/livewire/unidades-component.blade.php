<div class='container'>
    @include('CrudUni.form')
    <div>
        @include('CrudUni.Listar')
    </div>
</div>