<div>
    @include('auth.login')
</div>
