<div class="container">
    @include('secciones.formulario')
 
    <div>
        @include('secciones.listar')
     </div>
 </div>