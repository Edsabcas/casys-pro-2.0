<div class='container'>
    @include('Crud_mat.materias')
    <div>
        @include('Crud_mat.list_mat')
    </div>
</div>