<div class="container">
    @include('grados.formulario')
 
    <div>
        @include('grados.listar')
     </div>
 </div>
 
