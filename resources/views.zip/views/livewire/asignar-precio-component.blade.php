<div>
   @include('contabilidad.precios.index')
</div>
