<div class="container">
    @include('asignaciones.asignación maestro.formulario')
   
    <br>

    <div>
        @include('asignaciones.asignación maestro.listar')
    </div>
</div>
