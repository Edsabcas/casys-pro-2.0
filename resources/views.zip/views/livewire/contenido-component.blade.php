<div class='container'>
    @include('contenido.eleccion')

</div>
