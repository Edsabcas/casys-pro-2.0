<div class='container'>
    @include('Crud_Rel.relaciones')
    <div>
        @include('Crud_Rel.list_rel')
    </div>
</div>