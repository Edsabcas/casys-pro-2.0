<div>
    @include('admisiones.index')
</div>
