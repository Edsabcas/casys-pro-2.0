<div class="contenido">
    @include('auth.configperfil')   

</div>