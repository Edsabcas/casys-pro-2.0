<div class='container'>
    @include('Crud_Union.form')
    <div>
        @include('Crud_Union.List')
    </div>
</div>
