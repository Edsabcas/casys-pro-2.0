<div>
    <div class="container">
        @include('anuncios.anunciosmaestros.formmaestros')
    </div>
</div>
