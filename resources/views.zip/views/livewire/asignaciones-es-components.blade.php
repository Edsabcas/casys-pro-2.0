<div class="container">
    @include('asignaciones.asignación estudiantes.formulario')
   
    <br>

    <div>
        @include('asignaciones.asignación estudiantes.listar')
    </div>
</div>
