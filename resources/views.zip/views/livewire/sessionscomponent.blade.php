<div>
    @include('inicio')
</div>
