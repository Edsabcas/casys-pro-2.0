<div class='container'>
    @include('Calendarizacion.forms')
    <div>
        @include('Calendarizacion.listar')
    </div>
</div>
