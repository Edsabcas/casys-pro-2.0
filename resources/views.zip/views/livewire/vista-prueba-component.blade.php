<div>
    <div class="container">
        @include('vistaspruebas.vistaprueba')
    </div>
</div>
