<div class="container">
    @include('Grados.tipodejornada')
 
    <div>
        @include('Grados.listarjornada')
     </div>
 </div>