<div class='container'>
    @include('Consultar.consultar')
</div>
